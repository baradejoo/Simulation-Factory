
#include <package.hpp>
#include <iostream>

std::set<ElementID>Package::assigned_IDs = {};
std::set<ElementID>Package::freed_IDs = {};

bool Package::is_ID_assigned(const ElementID &id_to_assign)
{
    bool is_in = assigned_IDs.find(id_to_assign) != assigned_IDs.end();
    return is_in;
}

ElementID Package::give_id()
{
    ElementID id_to_be_given = 0;

    if(freed_IDs.empty()) {
        if(assigned_IDs.empty()) {
            id_to_be_given = 1;
        }

        else {
            id_to_be_given = *(assigned_IDs.rbegin())+1;
        }
    }

    else{
        id_to_be_given = *(freed_IDs.begin());
        freed_IDs.erase(id_to_be_given);
        assigned_IDs.emplace(id_to_be_given);
    }

    return id_to_be_given;
}
/*
ElementID Package::give_id() {
    ElementID id_to_be_given = 0;

    if(freed_IDs.empty() && assigned_IDs.empty()) {
        id_to_be_given = 1;

        ElementID given_id = id_to_be_given;
        freed_IDs.erase(given_id);
        assigned_IDs.emplace(given_id);

        return id_to_be_given;
    }

    do {
        id_to_be_given += 1;
    }
    while(is_ID_assigned(id_to_be_given));

    ElementID given_id = id_to_be_given;
    freed_IDs.erase(given_id);
    assigned_IDs.emplace(given_id);

    return given_id;

}


 ElementID Package::give_id()
{
    ElementID id_to_be_given = 1;

    if(freed_IDs.empty() && assigned_IDs.empty()) {
        id_to_be_given = 1;

        ElementID given_id = id_to_be_given;
        freed_IDs.erase(given_id);
        assigned_IDs.emplace(given_id);

        return id_to_be_given;
    }

    if(is_ID_assigned(id_to_be_given))
    {
        id_to_be_given = *freed_IDs.begin();
    }
    ElementID given_id = id_to_be_given;
    freed_IDs.erase(given_id);
    assigned_IDs.emplace(given_id);

    int i = 1;
    do {
        if(!is_ID_assigned(given_id+i)) {
            freed_IDs.emplace(given_id + i);
        }
        i++;
    }
    while(is_ID_assigned(given_id+i));

    return given_id;
}
 */