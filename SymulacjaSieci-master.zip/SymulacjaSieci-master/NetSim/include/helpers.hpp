#ifndef NETSIM_HELPERS_HPP
#define NETSIM_HELPERS_HPP

#include <cstdlib>
#include <iostream>
#include <random>
#include <ctime>

double get_random();
double your_num();


#endif //NETSIM_HELPERS_HPP
