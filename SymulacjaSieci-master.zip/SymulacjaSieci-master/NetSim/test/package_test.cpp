#include "gtest/gtest.h"
#include "gmock/gmock.h"

#include "package.hpp"

TEST(PackageInitTest, firstPackageID) {
    Package pack1;

    EXPECT_EQ(1, pack1.get_id());
}

TEST(PackageAssignTest, secondPackageID) {
    Package pack1;
    Package pack2;

    EXPECT_EQ(2, pack2.get_id());
}


TEST(PackageCopyTest, changePackageID) {
    Package pack1;
    Package pack2(static_cast<Package&&>(pack1));

    EXPECT_EQ(1, pack2.get_id());
}

TEST(PackageOperatorTest, changingPackageID) {
    Package pack1;
    Package pack2;

    pack2.operator=(static_cast<Package&&>(pack1));

    EXPECT_EQ(1, pack2.get_id());
}

TEST(PackageidTest, changePackageID){
    Package pack1;
    Package pack2;

    EXPECT_TRUE(pack1.get_id() != pack2.get_id());
}

//
// Created by Bartolemello on 15.12.2019.
//
#include "gtest/gtest.h"
#include "package.hpp"
#include "nodes.hpp"
#include "storage_types.hpp"

TEST(FabrykaPackageTest, CreationTest) {
    Package p1;
    Package p2;
    Package p3;
    Package p4;
    EXPECT_EQ(p1.get_id(), 1);
    EXPECT_EQ(p2.get_id(), 2);
    EXPECT_EQ(p3.get_id(), 3);
    EXPECT_EQ(p4.get_id(), 4);
}

